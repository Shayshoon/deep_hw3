#!/bin/bash

python3 ./main.py run-nb ./Part1_Sequence.ipynb
